import { Component, OnInit } from '@angular/core';
declare var $;
declare var AOS;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor() { }
  ngOnInit() {
    this.init()
  }
  public init() {
    AOS.init();
    var counter = 0;
    let colors = ["green", "blue", "turq"]
    setInterval(function () {
      $("div.home-hero__bg").attr("data-colour", colors[counter]);
      if (counter === 2) {
        counter = 0; // If counter = 3, set it back to 1 for next loop
      } else {
        counter++; // Else, add 1 to the counter
      }
    }, 3000);
  }
}
