import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BanksComponent } from './banks/banks.component';
import { MerchantsComponent } from './merchants/merchants.component';
import { CompanyComponent } from './company/company.component';
const routes: Routes =
  [
    {
      path: "",
      component: HomeComponent, data: { state: 'home' }
    },
    {
      path: "merchants",
      component: MerchantsComponent, data: { state: 'merchants' }
    },
    {
      path: "banks",
      component: BanksComponent, data: { state: 'banks' }
    },
    { path: '**', redirectTo: '/', }
  ]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BanksComponent,
    MerchantsComponent,
    CompanyComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes,{useHash:false}),BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
