import { Component, OnInit } from '@angular/core';
declare var AOS:any;
@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  constructor() { 
    AOS.init()
  }

  ngOnInit() {
  }

}
