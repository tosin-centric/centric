import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { routerTransition } from './shared/router.animation'
declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [routerTransition]
})
export class AppComponent implements OnInit {
  title = 'centric-website';
  public previousPath: string = '';
  getState(outlet: any) {
    return outlet.activatedRouteData.state;
  }
  getPageTransition(routerOutlet: RouterOutlet) {
    // return "forward";
    if (routerOutlet.isActivated) {
      let transitionName = 'section'
      const { path } = routerOutlet.activatedRoute.routeConfig
      const isSame = this.previousPath === path
      const isBackward = this.previousPath.startsWith(path)
      const isForward = path.startsWith(this.previousPath)
      if (isSame) {
        transitionName = 'none'
      } else if (isBackward && isForward) {
        transitionName = 'initial'
      } else if (isBackward) {
        transitionName = 'backward'
      } else if (isForward) {
        transitionName = 'forward'
      }
      this.previousPath = path;
      console.log(transitionName)
      return transitionName;
    }
  }
  ngOnInit() {
    $(document).ready(function () {
      window.addEventListener("scroll", function () {
      window.pageYOffset >= 30 ?
        this.document.getElementById("header").classList.add("is-scrolled")
        : this.document.getElementById("header").classList.remove("is-scrolled")
      }), window.pageYOffset >= 30 && this.document.getElementById("header").classList.add("is-scrolled")
    });
  }
}
