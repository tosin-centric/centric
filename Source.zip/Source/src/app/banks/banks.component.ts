import { Component, OnInit } from '@angular/core';
declare var AOS:any;
@Component({
  selector: 'app-banks',
  templateUrl: './banks.component.html',
  styleUrls: ['./banks.component.css']
})
export class BanksComponent implements OnInit {

  constructor() { 
  }

  ngOnInit() {
    AOS.init();
  }

}
